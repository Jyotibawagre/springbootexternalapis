# Spring Boot OAuth2-style JWT Security — Task Management API

A minimal real-world project to practice **Spring Security 6**, **JWT**, and **role-based authorization**.
Includes H2 in-memory DB and Swagger UI.

## Features
- Register & Login → returns JWT
- Protect APIs with JWT (Bearer token)
- Role-based endpoints (USER/ADMIN)
- H2 in-memory DB with seed users
- Swagger UI at `/swagger-ui.html`

## Tech Stack
- Spring Boot 3.x, Spring Security 6
- JPA, H2
- jjwt 0.11.5
- Springdoc OpenAPI

## Run
```bash
mvn spring-boot:run
```
App runs at `http://localhost:8080`.

## Try via Swagger
Open: `http://localhost:8080/swagger-ui.html`

## Seed Users
- admin / admin123  (ROLE_ADMIN, ROLE_USER)
- user  / user123   (ROLE_USER)

## API Flow
1) **Login** (get token)
```
POST /api/auth/login
Content-Type: application/json

{ "username": "admin", "password": "admin123" }
```
Response:
```
{ "token": "eyJhbGciOi..." }
```

2) **Use token** for protected endpoints
Add header:
```
Authorization: Bearer <token>
```

3) **Create a task (USER)**
```
POST /api/tasks
Content-Type: application/json
Authorization: Bearer <token>

{ "title": "Learn JWT", "description": "watch 30-min tutorial" }
```

4) **List my tasks**
```
GET /api/tasks
Authorization: Bearer <token>
```

5) **Admin-only endpoint**
```
GET /api/tasks/admin/metrics
Authorization: Bearer <admin token>
```

## Notes
- JWT secret is demo-only; change `jwt.secret` in `application.yml` for real use.
- H2 console at `/h2-console` (JDBC URL: `jdbc:h2:mem:testdb`).
- CSRF disabled for stateless JWT APIs.
