package com.example.security.service;

import com.example.security.entity.Task;
import com.example.security.entity.User;
import com.example.security.repository.TaskRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TaskService {
    private final TaskRepository taskRepository;

    public TaskService(TaskRepository taskRepository) {
        this.taskRepository = taskRepository;
    }

    public Task create(Task task) { return taskRepository.save(task); }

    public List<Task> findByOwner(User owner) { return taskRepository.findByOwner(owner); }
}
