package com.example.security.controller;

import com.example.security.entity.Task;
import com.example.security.entity.User;
import com.example.security.service.TaskService;
import com.example.security.service.UserService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/tasks")
public class TaskController {

    private final TaskService taskService;
    private final UserService userService;

    public TaskController(TaskService taskService, UserService userService) {
        this.taskService = taskService;
        this.userService = userService;
    }

    @GetMapping
    public ResponseEntity<List<Task>> myTasks(Authentication authentication) {
        User owner = userService.findByUsername(authentication.getName());
        return ResponseEntity.ok(taskService.findByOwner(owner));
    }

    @PostMapping
    public ResponseEntity<Task> create(@RequestBody Task task, Authentication authentication) {
        User owner = userService.findByUsername(authentication.getName());
        task.setOwner(owner);
        return ResponseEntity.ok(taskService.create(task));
    }

    @GetMapping("/admin/metrics")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<String> adminOnly() {
        return ResponseEntity.ok("Admin metrics!");
    }
}
