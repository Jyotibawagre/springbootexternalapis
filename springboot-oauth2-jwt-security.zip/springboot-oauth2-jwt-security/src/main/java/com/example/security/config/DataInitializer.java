package com.example.security.config;

import com.example.security.entity.User;
import com.example.security.repository.UserRepository;
import com.example.security.service.UserService;
import jakarta.annotation.PostConstruct;
import org.springframework.stereotype.Component;

import java.util.Set;

@Component
public class DataInitializer {

    private final UserRepository userRepository;
    private final UserService userService;

    public DataInitializer(UserRepository userRepository, UserService userService) {
        this.userRepository = userRepository;
        this.userService = userService;
    }

    @PostConstruct
    public void init() {
        if (!userRepository.existsByUsername("admin")) {
            userService.saveUser(new User("admin", "admin123", Set.of("ROLE_ADMIN", "ROLE_USER")));
        }
        if (!userRepository.existsByUsername("user")) {
            userService.saveUser(new User("user", "user123", Set.of("ROLE_USER")));
        }
    }
}
